import unittest

from archive_ocr.markup import parse_segments, strip_markup, tags_only, validate_markup


class MarkupTest(unittest.TestCase):
    def test_parse_and_strip(self) -> None:
        text = "Он <del>быстро</del> <add>медленно</add> вошёл."
        segments = parse_segments(text)
        self.assertEqual([segment.tag for segment in segments], [None, "del", None, "add", None])
        self.assertEqual(strip_markup(text), "Он быстро медленно вошёл.")
        self.assertEqual(strip_markup(text, keep_deleted=False), "Он медленно вошёл.")

    def test_tags_only(self) -> None:
        self.assertEqual(tags_only("<del>x</del>"), ["<del>", "</del>"])

    def test_reject_nested_markup(self) -> None:
        with self.assertRaises(ValueError):
            validate_markup("<del>a <unclear>b</unclear></del>")

    def test_reject_unknown_markup(self) -> None:
        with self.assertRaises(ValueError):
            validate_markup("<strike>x</strike>")


if __name__ == "__main__":
    unittest.main()

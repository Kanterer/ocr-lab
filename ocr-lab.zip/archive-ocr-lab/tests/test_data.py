import tempfile
import unittest
from pathlib import Path

from archive_ocr.data import check_group_leakage, load_manifest
from archive_ocr.schema import OCRRecord
from archive_ocr.synthetic import make_demo_dataset


class DataTest(unittest.TestCase):
    def test_synthetic_manifest_and_group_split(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            manifest = make_demo_dataset(directory, samples=18, seed=7)
            records = load_manifest(manifest, verify_images=True)
            self.assertEqual(len(records), 18)
            self.assertFalse(check_group_leakage(records))
            self.assertEqual({record.split for record in records}, {"train", "validation", "test"})

    def test_detect_group_leakage(self) -> None:
        rows = [
            OCRRecord(id="a", image="a.png", transcription="x", split="train", document_id="d"),
            OCRRecord(id="b", image="b.png", transcription="y", split="test", document_id="d"),
        ]
        self.assertEqual(check_group_leakage(rows), {"d": ["test", "train"]})


if __name__ == "__main__":
    unittest.main()


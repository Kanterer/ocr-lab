import tempfile
import unittest
from pathlib import Path

from PIL import Image

from archive_ocr.data import load_manifest
from archive_ocr.pagexml import convert_pagexml


PAGE_XML = """<?xml version="1.0" encoding="UTF-8"?>
<PcGts xmlns="http://schema.primaresearch.org/PAGE/gts/pagecontent/2019-07-15">
  <Page imageFilename="page.png" imageWidth="200" imageHeight="80">
    <TextRegion id="r1">
      <TextLine id="l1">
        <Coords points="10,10 180,10 180,35 10,35"/>
        <TextEquiv><Unicode>Пример строки</Unicode></TextEquiv>
      </TextLine>
    </TextRegion>
  </Page>
</PcGts>
"""


class PageXmlTest(unittest.TestCase):
    def test_convert(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            Image.new("RGB", (200, 80), "white").save(root / "page.png")
            (root / "page.xml").write_text(PAGE_XML, encoding="utf-8")
            manifest = convert_pagexml(root, root / "converted", language="ru")
            records = load_manifest(manifest, verify_images=True)
            self.assertEqual(len(records), 1)
            self.assertEqual(records[0].transcription, "Пример строки")
            self.assertEqual(records[0].bbox.x0, 10)


if __name__ == "__main__":
    unittest.main()


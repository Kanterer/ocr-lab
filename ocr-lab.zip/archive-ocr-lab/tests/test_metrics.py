import unittest

from archive_ocr.metrics import character_error_rate, edit_distance, evaluate_pairs, tag_f1


class MetricsTest(unittest.TestCase):
    def test_edit_distance(self) -> None:
        self.assertEqual(edit_distance("kitten", "sitting"), 3)

    def test_cer_ignores_markup_in_main_text_metric(self) -> None:
        result = evaluate_pairs(["a <del>b</del> c"], ["a b c"])
        self.assertEqual(result["cer"], 0.0)
        self.assertEqual(result["wer"], 0.0)
        self.assertEqual(result["tag_f1"], 0.0)

    def test_empty_reference_is_finite(self) -> None:
        self.assertEqual(character_error_rate("", "a"), 1.0)

    def test_tag_f1_exact(self) -> None:
        self.assertEqual(tag_f1("<add>x</add>", "<add>x</add>"), 1.0)

    def test_malformed_prediction_does_not_abort_evaluation(self) -> None:
        result = evaluate_pairs(["<del>x</del>"], ["<del>x"])
        self.assertEqual(result["cer"], 0.0)
        self.assertLess(result["tag_f1"], 1.0)


if __name__ == "__main__":
    unittest.main()

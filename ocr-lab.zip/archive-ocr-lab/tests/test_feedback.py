import tempfile
import unittest
from pathlib import Path

from archive_ocr.data import check_group_leakage, load_manifest
from archive_ocr.feedback import build_feedback_manifest, make_demo_feedback
from archive_ocr.synthetic import make_demo_dataset


class FeedbackTest(unittest.TestCase):
    def test_builds_replay_and_preserves_test(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            base_manifest = make_demo_dataset(root / "base", samples=30, seed=13)
            raw_feedback = make_demo_feedback(base_manifest, root / "raw.jsonl", samples=12, seed=4)
            summary = build_feedback_manifest(
                base_manifest,
                raw_feedback,
                root / "selected",
                replay_ratio=0.5,
                validation_ratio=0.2,
                seed=4,
            )
            records = load_manifest(root / "selected" / "manifest.jsonl", verify_images=True)
            self.assertGreater(summary["feedback_train"], 0)
            self.assertGreater(summary["replay"], 0)
            self.assertGreater(summary["untouched_test"], 0)
            self.assertFalse(check_group_leakage(records))


if __name__ == "__main__":
    unittest.main()


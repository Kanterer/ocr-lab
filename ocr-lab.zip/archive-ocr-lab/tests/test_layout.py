import unittest

from PIL import Image, ImageDraw

from archive_ocr.layout import ProjectionLineDetector


class LayoutTest(unittest.TestCase):
    def test_finds_two_horizontal_lines(self) -> None:
        image = Image.new("RGB", (300, 120), "white")
        draw = ImageDraw.Draw(image)
        draw.rectangle((20, 20, 260, 32), fill="black")
        draw.rectangle((35, 72, 280, 86), fill="black")
        lines = ProjectionLineDetector(min_height=5).detect(image)
        self.assertEqual(len(lines), 2)
        self.assertLess(lines[0].bbox.y0, lines[1].bbox.y0)


if __name__ == "__main__":
    unittest.main()


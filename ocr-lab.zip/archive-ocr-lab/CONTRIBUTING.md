# Contributing

Этот репозиторий — исследовательский prototype. Изменение должно быть воспроизводимым и
отвечать на проверяемую гипотезу.

## Локальная проверка

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -e ".[dev]"

make test
make lint
```

Минимальные CPU-тесты без ML-зависимостей:

```bash
python -m pip install pillow numpy pydantic pyyaml
PYTHONPATH=src python -m unittest discover -s tests -v
python -m compileall -q src
```

## Pull request

В PR укажите:

- одну основную гипотезу;
- версию данных и правила split;
- baseline и изменяемый фактор;
- overall и worst-slice метрики;
- compute/hardware и seed;
- CER/latency guardrails;
- известные ограничения.

Не выбирайте решение только по test set. Model selection выполняется по validation, test
остаётся неизменяемым до финального сравнения.

## Данные и приватность

Не коммитьте:

- checkpoints, ONNX и большие сгенерированные файлы;
- изображения/транскрипции без понятной лицензии;
- пользовательские изображения и необезличенные bug reports;
- API keys, токены и локальные `.env`;
- абсолютные локальные пути в manifests.

Для новой архивной коллекции добавьте data card: источник, лицензия, версия, языки, писцы,
правила транскрипции и document/writer-disjoint split.

## Стиль кода

- Python 3.10+;
- type hints для публичных функций;
- тяжёлые ML-импорты по возможности остаются lazy, чтобы CPU data tests были быстрыми;
- новый pipeline-инвариант сопровождается тестом;
- случайность должна иметь явный seed.


from __future__ import annotations

import re
from dataclasses import dataclass
from html import escape
from xml.etree import ElementTree as ET

ALLOWED_TAGS = ("del", "add", "unclear")
SPECIAL_TOKENS = [f"<{tag}>" for tag in ALLOWED_TAGS] + [f"</{tag}>" for tag in ALLOWED_TAGS]
TAG_RE = re.compile(r"</?(?:del|add|unclear)>")
SPACE_RE = re.compile(r"\s+")


@dataclass(frozen=True)
class Segment:
    text: str
    tag: str | None = None


def normalize_text(text: str) -> str:
    """Normalize spacing but preserve editorial tags and letter case."""

    text = text.replace("\u00a0", " ").strip()
    return SPACE_RE.sub(" ", text)


def parse_segments(text: str) -> list[Segment]:
    """Parse the project's deliberately small, non-nested editorial vocabulary."""

    validate_markup(text)
    root = ET.fromstring(f"<root>{text}</root>")
    segments: list[Segment] = []
    if root.text:
        segments.append(Segment(root.text))
    for child in root:
        segments.append(Segment(child.text or "", child.tag))
        if child.tail:
            segments.append(Segment(child.tail))
    return [segment for segment in segments if segment.text]


def validate_markup(text: str) -> None:
    """Reject malformed, nested, attributed, or unknown tags."""

    try:
        root = ET.fromstring(f"<root>{text}</root>")
    except ET.ParseError as error:
        raise ValueError(f"malformed editorial markup: {error}") from error
    for child in root:
        if child.tag not in ALLOWED_TAGS:
            raise ValueError(f"unsupported tag <{child.tag}>")
        if child.attrib:
            raise ValueError("editorial tags cannot have attributes")
        if list(child):
            raise ValueError("nested editorial tags are not supported")


def strip_markup(text: str, *, keep_deleted: bool = True) -> str:
    """Return readable text; optionally remove content marked as deleted."""

    parts: list[str] = []
    for segment in parse_segments(text):
        if segment.tag == "del" and not keep_deleted:
            continue
        parts.append(segment.text)
    return normalize_text("".join(parts))


def strip_markup_best_effort(text: str, *, keep_deleted: bool = True) -> str:
    """Strip known tags without letting malformed model output abort evaluation."""

    try:
        return strip_markup(text, keep_deleted=keep_deleted)
    except ValueError:
        if not keep_deleted:
            text = re.sub(r"<del>.*?(?:</del>|$)", "", text)
        return normalize_text(TAG_RE.sub("", text))


def tags_only(text: str) -> list[str]:
    return TAG_RE.findall(text)


def escape_plain_text(text: str) -> str:
    """Escape an imported plain transcription before adding project tags."""

    return escape(text, quote=False)

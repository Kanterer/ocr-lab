from __future__ import annotations

import io
import os
from contextlib import asynccontextmanager
from typing import Annotated, Literal

from fastapi import FastAPI, File, HTTPException, UploadFile
from PIL import Image, UnidentifiedImageError
from pydantic import BaseModel

from .layout import ProjectionLineDetector
from .models import decode_preserving_markup, load_trocr, resolve_device
from .schema import BBox


class RegionResult(BaseModel):
    text: str
    bbox: BBox


class RecognizeResponse(BaseModel):
    text: str
    regions: list[RegionResult]
    mode: Literal["line", "page"]


class OCRService:
    def __init__(self, checkpoint: str, device: str, max_new_tokens: int) -> None:
        import torch

        self.torch = torch
        self.processor, self.model = load_trocr(checkpoint)
        self.device = resolve_device(device)
        self.model.to(self.device).eval()
        self.max_new_tokens = max_new_tokens
        self.detector = ProjectionLineDetector()

    def recognize_line(self, image: Image.Image) -> str:
        inputs = self.processor(images=image.convert("RGB"), return_tensors="pt")
        with self.torch.inference_mode():
            tokens = self.model.generate(
                inputs.pixel_values.to(self.device), max_new_tokens=self.max_new_tokens
            )
        return decode_preserving_markup(self.processor, tokens)[0]

    def recognize(self, image: Image.Image, mode: Literal["line", "page"]) -> RecognizeResponse:
        if mode == "line":
            text = self.recognize_line(image)
            bbox = BBox(x0=0, y0=0, x1=image.width, y1=image.height)
            return RecognizeResponse(text=text, regions=[RegionResult(text=text, bbox=bbox)], mode=mode)
        detected = self.detector.detect(image)
        regions = [
            RegionResult(text=self.recognize_line(line.image), bbox=line.bbox) for line in detected
        ]
        return RecognizeResponse(
            text="\n".join(region.text for region in regions), regions=regions, mode=mode
        )


@asynccontextmanager
async def lifespan(app: FastAPI):
    checkpoint = os.getenv("ARCHIVE_OCR_CHECKPOINT", "outputs/trocr/best")
    device = os.getenv("ARCHIVE_OCR_DEVICE", "auto")
    max_new_tokens = int(os.getenv("ARCHIVE_OCR_MAX_NEW_TOKENS", "128"))
    app.state.ocr = OCRService(checkpoint, device, max_new_tokens)
    yield


app = FastAPI(
    title="Archive OCR Lab",
    version="0.1.0",
    description="Transformer OCR API for line crops and simple archival pages.",
    lifespan=lifespan,
)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/v1/recognize", response_model=RecognizeResponse)
async def recognize(
    file: Annotated[UploadFile, File(description="PNG or JPEG image")],
    mode: Literal["line", "page"] = "line",
) -> RecognizeResponse:
    payload = await file.read()
    if len(payload) > 15 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="image exceeds 15 MiB")
    try:
        image = Image.open(io.BytesIO(payload))
        image.load()
    except (UnidentifiedImageError, OSError) as error:
        raise HTTPException(status_code=400, detail="invalid image") from error
    return app.state.ocr.recognize(image, mode)

from __future__ import annotations

from pathlib import Path
from typing import Any

from PIL import Image

from .data import load_manifest
from .metrics import ErrorAccumulator, sliced_metrics
from .schema import PredictionRecord
from .utils import load_yaml, write_json


def _load_model(model_id: str) -> tuple[Any, Any]:
    import torch
    from transformers import AutoProcessor

    try:
        from transformers import AutoModelForImageTextToText

        model_class = AutoModelForImageTextToText
    except ImportError:
        from transformers import Qwen2_5_VLForConditionalGeneration

        model_class = Qwen2_5_VLForConditionalGeneration
    processor = AutoProcessor.from_pretrained(model_id)
    model = model_class.from_pretrained(
        model_id,
        torch_dtype="auto",
        device_map="auto" if torch.cuda.is_available() else None,
    )
    if not torch.cuda.is_available():
        model.to("cpu")
    return processor, model


def transcribe_image(
    image: Image.Image,
    *,
    prompt: str,
    processor: Any,
    model: Any,
    max_new_tokens: int,
) -> str:
    import torch

    messages = [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image.convert("RGB")},
                {"type": "text", "text": prompt},
            ],
        }
    ]
    rendered_prompt = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    inputs = processor(
        text=[rendered_prompt], images=[image.convert("RGB")], padding=True, return_tensors="pt"
    )
    device = next(model.parameters()).device
    inputs = {name: value.to(device) for name, value in inputs.items()}
    with torch.inference_mode():
        generated = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
    input_length = inputs["input_ids"].shape[1]
    answer_tokens = generated[:, input_length:]
    return processor.batch_decode(
        answer_tokens, skip_special_tokens=True, clean_up_tokenization_spaces=False
    )[0].strip()


def run_vlm_evaluation(config_path: str | Path) -> dict[str, Any]:
    config = load_yaml(config_path)
    records = [
        record
        for record in load_manifest(config["manifest"], verify_images=True)
        if record.split == config.get("split", "test")
    ][: int(config.get("limit", 40))]
    if not records:
        raise ValueError("selected VLM evaluation split is empty")
    processor, model = _load_model(config["model_id"])
    predictions: list[PredictionRecord] = []
    for record in records:
        with Image.open(record.resolved_image(config["manifest"])) as image:
            prediction = transcribe_image(
                image,
                prompt=config["prompt"],
                processor=processor,
                model=model,
                max_new_tokens=int(config.get("max_new_tokens", 192)),
            )
        predictions.append(
            PredictionRecord(
                id=record.id,
                image=record.image,
                reference=record.transcription,
                prediction=prediction,
                domain=record.domain,
                language=record.language,
                split=record.split,
                degradation=record.degradation,
            )
        )
    accumulator = ErrorAccumulator()
    for row in predictions:
        accumulator.add(row.reference, row.prediction)
    metrics = {
        "overall": accumulator.result(),
        "by_language": sliced_metrics(
            predictions,
            reference=lambda row: row.reference,
            prediction=lambda row: row.prediction,
            slice_value=lambda row: row.language,
        ),
    }
    output = Path(config["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    with (output / "predictions.jsonl").open("w", encoding="utf-8") as stream:
        for row in predictions:
            stream.write(row.model_dump_json() + "\n")
    write_json(output / "metrics.json", metrics)
    return metrics


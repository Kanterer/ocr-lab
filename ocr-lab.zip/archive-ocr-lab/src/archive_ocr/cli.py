from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.pretty import Pretty

from .data import check_group_leakage, load_manifest, manifest_summary

app = typer.Typer(
    no_args_is_help=True,
    help="Transformer OCR and VLM experiments for archival manuscripts.",
)
console = Console()


@app.command("make-demo-data")
def make_demo_data(
    output: Annotated[Path, typer.Option(help="Output data directory")] = Path("data/demo"),
    samples: Annotated[int, typer.Option(min=12)] = 120,
    seed: int = 42,
) -> None:
    """Generate an offline synthetic manuscript smoke dataset."""

    from .synthetic import make_demo_dataset

    manifest = make_demo_dataset(output, samples=samples, seed=seed)
    console.print(f"Created {manifest}")


@app.command("validate-data")
def validate_data(
    manifest: Path,
    verify_images: Annotated[bool, typer.Option("--verify-images/--no-verify-images")] = True,
) -> None:
    """Validate schema, markup, images, and document-group leakage."""

    records = load_manifest(manifest, verify_images=verify_images)
    leakage = check_group_leakage(records)
    summary = manifest_summary(records)
    summary["leaking_document_groups"] = leakage
    console.print(Pretty(summary))
    if leakage:
        raise typer.Exit(code=2)


@app.command("import-pagexml")
def import_pagexml(
    pagexml_dir: Path,
    output: Path,
    image_root: Path | None = None,
    split: str = "train",
    domain: str = "archive",
    language: str = "und",
    allow_markup: bool = False,
) -> None:
    """Crop PAGE XML text lines into the project manifest format."""

    from .pagexml import convert_pagexml

    if split not in {"train", "validation", "test"}:
        raise typer.BadParameter("split must be train, validation, or test")
    manifest = convert_pagexml(
        pagexml_dir,
        output,
        image_root=image_root,
        split=split,  # type: ignore[arg-type]
        domain=domain,
        language=language,
        allow_markup=allow_markup,
    )
    console.print(f"Created {manifest}")


@app.command("train")
def train(config: Path) -> None:
    """Fine-tune TrOCR according to a YAML experiment config."""

    from .train import run_training

    console.print(Pretty(run_training(config)))


@app.command("evaluate")
def evaluate(
    checkpoint: Path,
    manifest: Path,
    output: Path,
    split: str = "test",
    device: str = "auto",
    max_new_tokens: int = 128,
    limit: int | None = None,
) -> None:
    """Run OCR inference and write overall plus sliced metrics."""

    from .evaluate import run_evaluation

    metrics = run_evaluation(
        checkpoint,
        manifest,
        output,
        split=split,
        device=device,
        max_new_tokens=max_new_tokens,
        limit=limit,
    )
    console.print(Pretty(metrics))


@app.command("make-demo-feedback")
def demo_feedback(manifest: Path, output: Path = Path("data/feedback/raw.jsonl")) -> None:
    """Generate local fake corrections for testing the continual-learning path."""

    from .feedback import make_demo_feedback

    console.print(f"Created {make_demo_feedback(manifest, output)}")


@app.command("build-feedback")
def build_feedback(
    base_manifest: Path,
    feedback: Path,
    output: Path = Path("data/feedback"),
    max_feedback: int = 10_000,
    replay_ratio: float = 0.35,
    validation_ratio: float = 0.10,
    seed: int = 43,
) -> None:
    """Select hard reviewed bug reports and mix a base-domain replay buffer."""

    from .feedback import build_feedback_manifest

    summary = build_feedback_manifest(
        base_manifest,
        feedback,
        output,
        max_feedback=max_feedback,
        replay_ratio=replay_ratio,
        validation_ratio=validation_ratio,
        seed=seed,
    )
    console.print(Pretty(summary))


@app.command("vlm-evaluate")
def vlm_evaluate(config: Path) -> None:
    """Evaluate a promptable image-text VLM on the same held-out split."""

    from .vlm import run_vlm_evaluation

    console.print(Pretty(run_vlm_evaluation(config)))


@app.command("export-onnx")
def onnx_export(checkpoint: Path, output: Path, quantize: bool = False) -> None:
    """Export the portable final checkpoint to ONNX, optionally dynamic INT8."""

    from .export_onnx import export_onnx

    files = export_onnx(checkpoint, output, quantize=quantize)
    console.print(Pretty([str(path) for path in files]))


@app.command("benchmark")
def benchmark(
    checkpoint: Path,
    image: Path,
    device: str = "auto",
    warmup: int = 5,
    runs: int = 30,
    output: Path | None = None,
) -> None:
    """Measure warmed p50/p95 latency on the current machine."""

    from .benchmark import benchmark_checkpoint

    console.print(
        Pretty(
            benchmark_checkpoint(
                checkpoint,
                image,
                device=device,
                warmup=warmup,
                runs=runs,
                output=output,
            )
        )
    )


if __name__ == "__main__":
    app()

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

from PIL import Image

from .data import load_manifest
from .metrics import ErrorAccumulator, sliced_metrics
from .models import decode_preserving_markup, load_trocr, resolve_device
from .schema import PredictionRecord
from .utils import write_json


def _confidence(model: Any, generated: Any) -> float | None:
    try:
        transition = model.compute_transition_scores(
            generated.sequences, generated.scores, normalize_logits=True
        )
        values = transition[0]
        values = values[values < 0]
        if not len(values):
            return None
        return float(math.exp(float(values.mean().item())))
    except (AttributeError, RuntimeError, ValueError):
        return None


def run_evaluation(
    checkpoint: str | Path,
    manifest: str | Path,
    output_dir: str | Path,
    *,
    split: str = "test",
    device: str = "auto",
    max_new_tokens: int = 128,
    limit: int | None = None,
) -> dict[str, Any]:
    import torch

    processor, model = load_trocr(str(checkpoint))
    resolved_device = resolve_device(device)
    model.to(resolved_device).eval()
    records = [record for record in load_manifest(manifest, verify_images=True) if record.split == split]
    if limit is not None:
        records = records[:limit]
    if not records:
        raise ValueError(f"no records in split {split!r}")

    predictions: list[PredictionRecord] = []
    for record in records:
        with Image.open(record.resolved_image(manifest)) as image:
            inputs = processor(images=image.convert("RGB"), return_tensors="pt")
        pixel_values = inputs.pixel_values.to(resolved_device)
        with torch.inference_mode():
            generated = model.generate(
                pixel_values,
                max_new_tokens=max_new_tokens,
                return_dict_in_generate=True,
                output_scores=True,
            )
        text = decode_preserving_markup(processor, generated.sequences)[0]
        predictions.append(
            PredictionRecord(
                id=record.id,
                image=record.image,
                reference=record.transcription,
                prediction=text,
                confidence=_confidence(model, generated),
                domain=record.domain,
                language=record.language,
                split=record.split,
                degradation=record.degradation,
            )
        )

    overall = ErrorAccumulator()
    for row in predictions:
        overall.add(row.reference, row.prediction)
    degradation_rows = []
    for row in predictions:
        if not row.degradation:
            degradation_rows.append((row, "clean"))
        else:
            degradation_rows.extend((row, degradation) for degradation in row.degradation)
    metrics = {
        "overall": overall.result(),
        "by_domain": sliced_metrics(
            predictions,
            reference=lambda row: row.reference,
            prediction=lambda row: row.prediction,
            slice_value=lambda row: row.domain,
        ),
        "by_language": sliced_metrics(
            predictions,
            reference=lambda row: row.reference,
            prediction=lambda row: row.prediction,
            slice_value=lambda row: row.language,
        ),
        "by_degradation": sliced_metrics(
            degradation_rows,
            reference=lambda item: item[0].reference,
            prediction=lambda item: item[0].prediction,
            slice_value=lambda item: item[1],
        ),
    }
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "predictions.jsonl").open("w", encoding="utf-8") as stream:
        for row in predictions:
            stream.write(row.model_dump_json(exclude_none=True) + "\n")
    write_json(output_dir / "metrics.json", metrics)
    return metrics

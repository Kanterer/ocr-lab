from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

Split = Literal["train", "validation", "test"]


class BBox(BaseModel):
    """Axis-aligned box in source-image pixel coordinates."""

    x0: int = Field(ge=0)
    y0: int = Field(ge=0)
    x1: int = Field(gt=0)
    y1: int = Field(gt=0)

    @model_validator(mode="after")
    def check_order(self) -> "BBox":
        if self.x1 <= self.x0 or self.y1 <= self.y0:
            raise ValueError("bbox must satisfy x1 > x0 and y1 > y0")
        return self


class OCRRecord(BaseModel):
    """One supervised OCR item, normally one line crop."""

    model_config = ConfigDict(extra="allow")

    id: str = Field(min_length=1)
    image: str = Field(min_length=1)
    transcription: str
    split: Split
    domain: str = "unknown"
    language: str = "und"
    source: str = "local"
    document_id: str | None = None
    writer_id: str | None = None
    bbox: BBox | None = None
    degradation: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("id", "domain", "language", "source")
    @classmethod
    def strip_nonempty(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("value must not be blank")
        return value

    def resolved_image(self, manifest_path: str | Path) -> Path:
        path = Path(self.image)
        if path.is_absolute():
            return path
        return (Path(manifest_path).resolve().parent / path).resolve()


class FeedbackRecord(BaseModel):
    """A reviewed user correction suitable for continual fine-tuning."""

    model_config = ConfigDict(extra="allow")

    id: str = Field(min_length=1)
    image: str = Field(min_length=1)
    prediction: str
    correction: str
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    accepted: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    domain: str = "user_feedback"
    language: str = "und"
    document_id: str | None = None
    reporter_count: int = Field(default=1, ge=1)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("created_at")
    @classmethod
    def make_timezone_aware(cls, value: datetime) -> datetime:
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value


class PredictionRecord(BaseModel):
    id: str
    image: str
    reference: str
    prediction: str
    confidence: float | None = None
    domain: str
    language: str
    split: Split
    degradation: list[str] = Field(default_factory=list)


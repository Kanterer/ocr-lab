from __future__ import annotations

import re
from pathlib import Path
from xml.etree import ElementTree as ET

from PIL import Image

from .data import write_manifest
from .markup import escape_plain_text, validate_markup
from .schema import BBox, OCRRecord, Split

POINT_RE = re.compile(r"(\d+),(\d+)")


def _first_descendant(element: ET.Element, suffix: str) -> ET.Element | None:
    return next((item for item in element.iter() if item.tag.endswith(suffix)), None)


def _coords(text_line: ET.Element) -> BBox:
    coords = _first_descendant(text_line, "Coords")
    if coords is None or not coords.attrib.get("points"):
        raise ValueError("TextLine has no Coords points")
    points = [(int(x), int(y)) for x, y in POINT_RE.findall(coords.attrib["points"])]
    if not points:
        raise ValueError("TextLine coordinates cannot be parsed")
    xs, ys = zip(*points, strict=True)
    return BBox(x0=min(xs), y0=min(ys), x1=max(xs) + 1, y1=max(ys) + 1)


def _transcription(text_line: ET.Element, *, allow_markup: bool) -> str:
    unicode_node = _first_descendant(text_line, "Unicode")
    if unicode_node is None or unicode_node.text is None:
        raise ValueError("TextLine has no TextEquiv/Unicode transcription")
    text = unicode_node.text.strip()
    if allow_markup:
        validate_markup(text)
        return text
    return escape_plain_text(text)


def convert_pagexml(
    pagexml_dir: str | Path,
    output: str | Path,
    *,
    image_root: str | Path | None = None,
    split: Split = "train",
    domain: str = "archive",
    language: str = "und",
    allow_markup: bool = False,
) -> Path:
    """Convert PAGE XML TextLine polygons to cropped line images and JSONL."""

    pagexml_dir = Path(pagexml_dir)
    output = Path(output)
    crop_dir = output / "images"
    crop_dir.mkdir(parents=True, exist_ok=True)
    records: list[OCRRecord] = []
    for xml_path in sorted(pagexml_dir.rglob("*.xml")):
        root = ET.parse(xml_path).getroot()
        page = _first_descendant(root, "Page")
        if page is None:
            continue
        image_name = page.attrib.get("imageFilename")
        if not image_name:
            raise ValueError(f"PAGE XML has no imageFilename: {xml_path}")
        base = Path(image_root) if image_root else xml_path.parent
        image_path = base / image_name
        with Image.open(image_path) as page_image:
            for index, text_line in enumerate(item for item in page.iter() if item.tag.endswith("TextLine")):
                bbox = _coords(text_line)
                if bbox.x1 > page_image.width or bbox.y1 > page_image.height:
                    raise ValueError(
                        f"TextLine {text_line.attrib.get('id', index)!r} is outside "
                        f"the {page_image.width}x{page_image.height} page image"
                    )
                transcription = _transcription(text_line, allow_markup=allow_markup)
                line_id = text_line.attrib.get("id") or f"line-{index:04d}"
                record_id = f"{xml_path.stem}-{line_id}"
                crop_name = f"{record_id}.png"
                page_image.crop((bbox.x0, bbox.y0, bbox.x1, bbox.y1)).convert("RGB").save(
                    crop_dir / crop_name
                )
                records.append(
                    OCRRecord(
                        id=record_id,
                        image=f"images/{crop_name}",
                        transcription=transcription,
                        split=split,
                        domain=domain,
                        language=language,
                        source="pagexml",
                        document_id=xml_path.stem,
                        bbox=bbox,
                        metadata={"page_image": str(image_path), "pagexml": str(xml_path)},
                    )
                )
    if not records:
        raise ValueError(f"no PAGE XML text lines found under {pagexml_dir}")
    manifest = output / "manifest.jsonl"
    write_manifest(manifest, records)
    return manifest

from __future__ import annotations

import statistics
import time
from pathlib import Path
from typing import Any

from PIL import Image

from .models import load_trocr, resolve_device
from .utils import write_json


def benchmark_checkpoint(
    checkpoint: str | Path,
    image_path: str | Path,
    *,
    device: str = "auto",
    warmup: int = 5,
    runs: int = 30,
    max_new_tokens: int = 128,
    output: str | Path | None = None,
) -> dict[str, Any]:
    """Measure warmed single-image latency; suitable for comparisons, not phone claims."""

    if warmup < 0 or runs < 2:
        raise ValueError("warmup must be non-negative and runs must be at least 2")
    import torch

    processor, model = load_trocr(str(checkpoint))
    resolved_device = resolve_device(device)
    model.to(resolved_device).eval()
    with Image.open(image_path) as image:
        pixel_values = processor(images=image.convert("RGB"), return_tensors="pt").pixel_values.to(
            resolved_device
        )

    def synchronize() -> None:
        if resolved_device.startswith("cuda"):
            torch.cuda.synchronize()

    def infer() -> Any:
        with torch.inference_mode():
            return model.generate(pixel_values, max_new_tokens=max_new_tokens)

    for _ in range(warmup):
        infer()
    synchronize()
    if resolved_device.startswith("cuda"):
        torch.cuda.reset_peak_memory_stats()
    timings: list[float] = []
    tokens = None
    for _ in range(runs):
        start = time.perf_counter()
        tokens = infer()
        synchronize()
        timings.append((time.perf_counter() - start) * 1000)
    sorted_times = sorted(timings)
    p95_index = min(len(sorted_times) - 1, int(0.95 * len(sorted_times)))
    result: dict[str, Any] = {
        "checkpoint": str(checkpoint),
        "device": resolved_device,
        "warmup": warmup,
        "runs": runs,
        "latency_ms": {
            "mean": statistics.mean(timings),
            "p50": statistics.median(timings),
            "p95": sorted_times[p95_index],
            "min": min(timings),
            "max": max(timings),
        },
        "generated_tokens": int(tokens.shape[1]) if tokens is not None else None,
    }
    if resolved_device.startswith("cuda"):
        result["peak_gpu_memory_mib"] = torch.cuda.max_memory_allocated() / (1024**2)
    if output is not None:
        write_json(output, result)
    return result

from __future__ import annotations

import io
import random
from dataclasses import dataclass

import numpy as np
from PIL import Image, ImageDraw, ImageEnhance, ImageFilter


@dataclass(frozen=True)
class AugmentationResult:
    image: Image.Image
    degradations: list[str]


class ArchiveAugmenter:
    """Lightweight archival degradations with a local deterministic RNG."""

    def __init__(self, seed: int, probability: float = 0.65) -> None:
        self.rng = random.Random(seed)
        self.probability = probability

    def __call__(self, image: Image.Image) -> AugmentationResult:
        image = image.convert("RGB")
        applied: list[str] = []
        operations = [
            ("paper_noise", self._paper_noise),
            ("blur", self._blur),
            ("faded_ink", self._faded_ink),
            ("rotation", self._rotation),
            ("fold", self._fold),
            ("stain", self._stain),
            ("jpeg", self._jpeg),
        ]
        self.rng.shuffle(operations)
        for name, operation in operations[: self.rng.randint(1, 3)]:
            if self.rng.random() <= self.probability:
                image = operation(image)
                applied.append(name)
        return AugmentationResult(image=image, degradations=applied)

    def _paper_noise(self, image: Image.Image) -> Image.Image:
        array = np.asarray(image).astype(np.int16)
        rng = np.random.default_rng(self.rng.randrange(2**32))
        noise = rng.normal(0, self.rng.uniform(2.0, 8.0), size=array.shape[:2] + (1,))
        tint = np.array([self.rng.randint(0, 7), self.rng.randint(-2, 4), -self.rng.randint(0, 8)])
        return Image.fromarray(np.clip(array + noise + tint, 0, 255).astype(np.uint8), "RGB")

    def _blur(self, image: Image.Image) -> Image.Image:
        return image.filter(ImageFilter.GaussianBlur(self.rng.uniform(0.25, 1.2)))

    def _faded_ink(self, image: Image.Image) -> Image.Image:
        return ImageEnhance.Contrast(image).enhance(self.rng.uniform(0.55, 0.88))

    def _rotation(self, image: Image.Image) -> Image.Image:
        return image.rotate(
            self.rng.uniform(-2.2, 2.2),
            resample=Image.Resampling.BICUBIC,
            fillcolor=(244, 239, 222),
        )

    def _fold(self, image: Image.Image) -> Image.Image:
        image = image.copy()
        draw = ImageDraw.Draw(image, "RGBA")
        x = self.rng.randint(image.width // 5, image.width * 4 // 5)
        width = self.rng.randint(2, 7)
        draw.rectangle((x - width, 0, x, image.height), fill=(75, 60, 40, 18))
        draw.rectangle((x + 1, 0, x + width, image.height), fill=(255, 255, 255, 45))
        return image

    def _stain(self, image: Image.Image) -> Image.Image:
        overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay, "RGBA")
        x = self.rng.randint(0, image.width)
        y = self.rng.randint(0, image.height)
        radius = self.rng.randint(12, max(14, image.height // 2))
        draw.ellipse(
            (x - radius * 2, y - radius, x + radius * 2, y + radius),
            fill=(125, 79, 31, self.rng.randint(8, 25)),
        )
        overlay = overlay.filter(ImageFilter.GaussianBlur(radius / 3))
        return Image.alpha_composite(image.convert("RGBA"), overlay).convert("RGB")

    def _jpeg(self, image: Image.Image) -> Image.Image:
        buffer = io.BytesIO()
        image.save(buffer, format="JPEG", quality=self.rng.randint(35, 78))
        buffer.seek(0)
        return Image.open(buffer).convert("RGB")


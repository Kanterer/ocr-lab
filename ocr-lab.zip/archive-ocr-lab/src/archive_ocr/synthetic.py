from __future__ import annotations

import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageFilter

from .augment import ArchiveAugmenter
from .data import write_manifest
from .markup import Segment, parse_segments
from .schema import OCRRecord
from .utils import set_seed

TEXTS = [
    "Вечером дорога стала тише.",
    "Он остановился у старого дома.",
    "Письмо осталось без ответа.",
    "Сад после дождя пах землёй.",
    "Мысль возвращалась снова и снова.",
    "На полях сохранилась короткая заметка.",
    "Черновик оказался труднее беловой рукописи.",
    "The archive keeps more than the final sentence.",
    "A crossed-out word can change the whole interpretation.",
]

MARKED_TEXTS = [
    "Он <del>быстро</del> медленно вошёл в комнату.",
    "Дорога была <del>пустой</del> <add>безлюдной</add>.",
    "Я хотел <add>сначала</add> объяснить эту мысль.",
    "На полях осталось <unclear>одно слово</unclear>.",
    "The line was <del>finished</del> <add>rewritten</add> later.",
    "Она сказала <del>тихо</del> почти шёпотом.",
]


def _font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


def render_editorial_line(text: str, *, seed: int, width: int = 1120, height: int = 144) -> Image.Image:
    rng = random.Random(seed)
    paper = (rng.randint(237, 248), rng.randint(232, 243), rng.randint(212, 232))
    image = Image.new("RGB", (width, height), paper)
    draw = ImageDraw.Draw(image)
    font = _font(rng.randint(29, 35))
    small_font = _font(rng.randint(21, 25))
    ink = (rng.randint(25, 65), rng.randint(22, 55), rng.randint(17, 45))
    x = rng.randint(18, 35)
    baseline_y = rng.randint(69, 84)
    for segment in parse_segments(text):
        active_font = small_font if segment.tag == "add" else font
        y = baseline_y - 39 if segment.tag == "add" else baseline_y
        draw.text((x, y), segment.text, fill=ink, font=active_font)
        box = draw.textbbox((x, y), segment.text, font=active_font)
        segment_width = box[2] - box[0]
        if segment.tag == "del":
            strike_y = y + (box[3] - box[1]) // 2 + 5
            draw.line((x - 2, strike_y, x + segment_width + 2, strike_y), fill=ink, width=2)
            if rng.random() < 0.5:
                draw.line((x, strike_y + 4, x + segment_width, strike_y - 2), fill=ink, width=1)
        elif segment.tag == "add":
            caret_x = x + segment_width // 2
            draw.line((caret_x - 6, baseline_y + 7, caret_x, baseline_y), fill=ink, width=2)
            draw.line((caret_x, baseline_y, caret_x + 6, baseline_y + 7), fill=ink, width=2)
        elif segment.tag == "unclear":
            region = image.crop((x, y, min(width, x + segment_width + 3), min(height, box[3] + 3)))
            region = region.filter(ImageFilter.GaussianBlur(0.75))
            image.paste(region, (x, y))
            draw = ImageDraw.Draw(image)
        x += segment_width
        if x >= width - 25:
            break
    return image


def make_demo_dataset(output: str | Path, *, samples: int = 120, seed: int = 42) -> Path:
    """Create grouped synthetic data for a zero-download pipeline smoke test."""

    if samples < 12:
        raise ValueError("at least 12 samples are required for grouped splits")
    set_seed(seed)
    output = Path(output)
    image_dir = output / "images"
    image_dir.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    records: list[OCRRecord] = []
    documents = max(12, samples // 3)
    for index in range(samples):
        document_index = index % documents
        ratio = document_index / documents
        split = "train" if ratio < 0.70 else "validation" if ratio < 0.85 else "test"
        marked = rng.random() < 0.55
        text = rng.choice(MARKED_TEXTS if marked else TEXTS)
        base = render_editorial_line(text, seed=seed * 100_000 + index)
        augmented = ArchiveAugmenter(seed=seed * 200_000 + index)(base)
        filename = f"line-{index:05d}.png"
        augmented.image.save(image_dir / filename)
        records.append(
            OCRRecord(
                id=f"demo-{index:05d}",
                image=f"images/{filename}",
                transcription=text,
                split=split,
                domain="synthetic_archive",
                language="ru" if any("а" <= char.lower() <= "я" for char in text) else "en",
                source="generated",
                document_id=f"demo-doc-{document_index:04d}",
                writer_id=f"synthetic-hand-{document_index % 7}",
                degradation=augmented.degradations,
                metadata={"contains_editorial_markup": marked, "generator_seed": seed},
            )
        )
    manifest = output / "manifest.jsonl"
    write_manifest(manifest, records)
    return manifest

from __future__ import annotations

import shutil
from pathlib import Path


def export_onnx(
    checkpoint: str | Path, output: str | Path, *, quantize: bool = False
) -> list[Path]:
    """Export a VisionEncoderDecoder checkpoint using Optimum's supported path."""

    from optimum.onnxruntime import ORTModelForVision2Seq
    from transformers import AutoProcessor

    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    model = ORTModelForVision2Seq.from_pretrained(str(checkpoint), export=True)
    processor = AutoProcessor.from_pretrained(str(checkpoint))
    model.save_pretrained(output)
    processor.save_pretrained(output)
    onnx_files = sorted(output.glob("*.onnx"))
    if not onnx_files:
        raise RuntimeError("Optimum export completed but produced no ONNX files")
    if quantize:
        from onnxruntime.quantization import QuantType, quantize_dynamic

        quantized_dir = output / "int8"
        quantized_dir.mkdir(exist_ok=True)
        for source in onnx_files:
            destination = quantized_dir / source.name
            quantize_dynamic(str(source), str(destination), weight_type=QuantType.QInt8)
        for source in output.iterdir():
            if source.is_file() and source.suffix != ".onnx":
                shutil.copy2(source, quantized_dir / source.name)
        return sorted(quantized_dir.glob("*.onnx"))
    return onnx_files


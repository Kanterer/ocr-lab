from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from PIL import Image

from .schema import BBox


@dataclass(frozen=True)
class DetectedLine:
    bbox: BBox
    image: Image.Image


class ProjectionLineDetector:
    """Explainable baseline for near-horizontal text lines.

    It is intentionally not a universal detector. Its value is a cheap baseline
    and a clean interface that can later be replaced by a learned detector.
    """

    def __init__(
        self,
        *,
        ink_threshold: int = 205,
        min_row_ink_ratio: float = 0.006,
        min_height: int = 8,
        merge_gap: int = 5,
        padding: int = 6,
    ) -> None:
        self.ink_threshold = ink_threshold
        self.min_row_ink_ratio = min_row_ink_ratio
        self.min_height = min_height
        self.merge_gap = merge_gap
        self.padding = padding

    def detect(self, image: Image.Image) -> list[DetectedLine]:
        grayscale = np.asarray(image.convert("L"))
        ink = grayscale < self.ink_threshold
        active = ink.mean(axis=1) >= self.min_row_ink_ratio
        runs = self._runs(active)
        runs = self._merge(runs)
        detected: list[DetectedLine] = []
        for y0, y1 in runs:
            if y1 - y0 < self.min_height:
                continue
            band = ink[y0:y1]
            active_columns = np.where(band.any(axis=0))[0]
            if not len(active_columns):
                continue
            x0 = max(0, int(active_columns[0]) - self.padding)
            x1 = min(image.width, int(active_columns[-1]) + self.padding + 1)
            top = max(0, y0 - self.padding)
            bottom = min(image.height, y1 + self.padding)
            bbox = BBox(x0=x0, y0=top, x1=x1, y1=bottom)
            detected.append(DetectedLine(bbox=bbox, image=image.crop((x0, top, x1, bottom))))
        return detected

    @staticmethod
    def _runs(active: np.ndarray) -> list[tuple[int, int]]:
        runs: list[tuple[int, int]] = []
        start: int | None = None
        for index, value in enumerate(active):
            if value and start is None:
                start = index
            elif not value and start is not None:
                runs.append((start, index))
                start = None
        if start is not None:
            runs.append((start, len(active)))
        return runs

    def _merge(self, runs: list[tuple[int, int]]) -> list[tuple[int, int]]:
        merged: list[tuple[int, int]] = []
        for run in runs:
            if merged and run[0] - merged[-1][1] <= self.merge_gap:
                merged[-1] = (merged[-1][0], run[1])
            else:
                merged.append(run)
        return merged


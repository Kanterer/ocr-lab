from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from .markup import SPECIAL_TOKENS


def load_trocr(
    model_id: str,
    *,
    freeze_encoder: bool = False,
    lora: dict[str, Any] | None = None,
) -> tuple[Any, Any]:
    """Load TrOCR, extend its decoder vocabulary, and optionally add decoder LoRA."""

    from transformers import TrOCRProcessor, VisionEncoderDecoderModel

    processor = TrOCRProcessor.from_pretrained(model_id)
    model = VisionEncoderDecoderModel.from_pretrained(model_id)

    added = processor.tokenizer.add_special_tokens({"additional_special_tokens": SPECIAL_TOKENS})
    if added:
        model.decoder.resize_token_embeddings(len(processor.tokenizer))

    tokenizer = processor.tokenizer
    model.config.decoder_start_token_id = tokenizer.cls_token_id or tokenizer.bos_token_id
    model.config.eos_token_id = tokenizer.sep_token_id or tokenizer.eos_token_id
    model.config.pad_token_id = tokenizer.pad_token_id
    model.generation_config.decoder_start_token_id = model.config.decoder_start_token_id
    model.generation_config.eos_token_id = model.config.eos_token_id
    model.generation_config.pad_token_id = model.config.pad_token_id

    if freeze_encoder:
        for parameter in model.encoder.parameters():
            parameter.requires_grad = False

    if lora and lora.get("enabled", False):
        model.decoder = _add_decoder_lora(model.decoder, lora)
    return processor, model


def _candidate_lora_targets(decoder: Any) -> list[str]:
    leaf_names = {name.rsplit(".", 1)[-1] for name, _ in decoder.named_modules()}
    for candidates in (
        ["q_proj", "v_proj"],
        ["query", "value"],
        ["q_lin", "v_lin"],
        ["c_attn"],
    ):
        if all(candidate in leaf_names for candidate in candidates):
            return candidates
    raise ValueError(
        "could not infer LoRA attention modules; inspect decoder.named_modules() "
        "and set lora.target_modules explicitly"
    )


def _add_decoder_lora(decoder: Any, config: dict[str, Any]) -> Any:
    from peft import LoraConfig, TaskType, get_peft_model

    configured = config.get("target_modules", "auto")
    targets: Sequence[str]
    if configured == "auto":
        targets = _candidate_lora_targets(decoder)
    elif isinstance(configured, str):
        targets = [configured]
    else:
        targets = configured
    peft_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=int(config.get("rank", 8)),
        lora_alpha=int(config.get("alpha", 16)),
        lora_dropout=float(config.get("dropout", 0.05)),
        target_modules=list(targets),
        bias="none",
    )
    return get_peft_model(decoder, peft_config)


def trainable_parameter_summary(model: Any) -> dict[str, int | float]:
    total = sum(parameter.numel() for parameter in model.parameters())
    trainable = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
    return {
        "total": total,
        "trainable": trainable,
        "trainable_fraction": trainable / max(1, total),
    }


def decode_preserving_markup(processor: Any, token_ids: Any) -> list[str]:
    """Drop model control tokens while retaining editorial special tokens."""

    texts = processor.batch_decode(token_ids, skip_special_tokens=False)
    controls = set(processor.tokenizer.all_special_tokens) - set(
        processor.tokenizer.additional_special_tokens
    )
    for control in controls:
        texts = [text.replace(control, "") for text in texts]
    return [text.strip() for text in texts]


def resolve_device(requested: str = "auto") -> str:
    if requested != "auto":
        return requested
    import torch

    if torch.cuda.is_available():
        return "cuda"
    if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return "mps"
    return "cpu"

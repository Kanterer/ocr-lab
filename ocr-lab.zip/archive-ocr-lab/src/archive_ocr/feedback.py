from __future__ import annotations

import json
import math
import os
import random
from datetime import datetime, timezone
from pathlib import Path

from .data import load_manifest, write_manifest
from .markup import normalize_text, validate_markup
from .metrics import character_error_rate
from .schema import FeedbackRecord, OCRRecord
from .utils import sha1_file, write_json


def _portable_relative_path(target: Path, parent: Path) -> str:
    return Path(os.path.relpath(target.resolve(), parent.resolve())).as_posix()


def load_feedback(path: str | Path) -> list[FeedbackRecord]:
    records: list[FeedbackRecord] = []
    seen: set[str] = set()
    with Path(path).open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            try:
                record = FeedbackRecord.model_validate_json(line)
                validate_markup(record.correction)
            except Exception as error:
                raise ValueError(f"invalid feedback row {line_number}: {error}") from error
            if record.id in seen:
                raise ValueError(f"duplicate feedback id at row {line_number}: {record.id}")
            seen.add(record.id)
            records.append(record)
    return records


def hardness_score(record: FeedbackRecord, *, newest: datetime) -> float:
    """Rank corrections by OCR error, uncertainty, repeat reports, and recency."""

    error = min(2.0, character_error_rate(record.correction, record.prediction)) / 2.0
    uncertainty = 1.0 - (record.confidence if record.confidence is not None else 0.5)
    age_days = max(0.0, (newest - record.created_at).total_seconds() / 86_400)
    recency = math.exp(-age_days / 90.0)
    repeat_signal = min(1.0, math.log1p(record.reporter_count) / math.log(6))
    return 0.45 * error + 0.25 * uncertainty + 0.20 * recency + 0.10 * repeat_signal


def _fingerprint(record: FeedbackRecord, feedback_path: Path) -> str:
    image = Path(record.image)
    if not image.is_absolute():
        image = (feedback_path.parent / image).resolve()
    image_key = sha1_file(image) if image.is_file() else str(image)
    return f"{image_key}:{normalize_text(record.correction)}"


def build_feedback_manifest(
    base_manifest: str | Path,
    feedback_path: str | Path,
    output: str | Path,
    *,
    max_feedback: int = 10_000,
    replay_ratio: float = 0.35,
    validation_ratio: float = 0.10,
    seed: int = 43,
) -> dict[str, int]:
    """Build time-split hard-feedback fine-tuning data with base-domain replay.

    The untouched base test set is copied through and never used for selection.
    Feedback from the newest time window becomes validation, which is closer to
    the real continual-learning setup than a random row split.
    """

    if not 0 <= replay_ratio <= 1 or not 0 < validation_ratio < 0.5:
        raise ValueError("replay_ratio must be in [0, 1] and validation_ratio in (0, .5)")
    rng = random.Random(seed)
    base_manifest = Path(base_manifest)
    feedback_path = Path(feedback_path)
    output = Path(output)
    base = load_manifest(base_manifest, verify_images=False)
    loaded_feedback = load_feedback(feedback_path)
    feedback = [record for record in loaded_feedback if record.accepted and record.correction]
    if not feedback:
        raise ValueError("no accepted feedback records")

    base_test_groups = {record.document_id or record.id for record in base if record.split == "test"}
    skipped_test_overlap = sum(
        (record.document_id or record.id) in base_test_groups for record in feedback
    )
    feedback = [
        record for record in feedback if (record.document_id or record.id) not in base_test_groups
    ]
    if not feedback:
        raise ValueError("all accepted feedback overlaps the immutable base test set")
    deduplicated: dict[str, FeedbackRecord] = {}
    for record in sorted(feedback, key=lambda item: item.created_at):
        deduplicated[_fingerprint(record, feedback_path)] = record
    feedback = sorted(deduplicated.values(), key=lambda item: item.created_at)
    validation_count = max(1, round(len(feedback) * validation_ratio))
    # Split whole documents, not rows. Several corrections from one manuscript
    # page must never land on both sides of validation.
    groups: dict[str, list[FeedbackRecord]] = {}
    for record in feedback:
        groups.setdefault(record.document_id or record.id, []).append(record)
    ordered_groups = sorted(
        groups.values(), key=lambda group: max(item.created_at for item in group), reverse=True
    )
    feedback_validation: list[FeedbackRecord] = []
    validation_group_ids: set[str] = set()
    for group in ordered_groups:
        if len(feedback_validation) >= validation_count:
            break
        feedback_validation.extend(group)
        validation_group_ids.add(group[0].document_id or group[0].id)
    feedback_train = [
        record
        for record in feedback
        if (record.document_id or record.id) not in validation_group_ids
    ]
    if not feedback_train:
        raise ValueError("at least two distinct feedback records are required")

    newest = feedback[-1].created_at
    feedback_train = sorted(
        feedback_train,
        key=lambda item: hardness_score(item, newest=newest),
        reverse=True,
    )[:max_feedback]
    base_train = [
        record
        for record in base
        if record.split == "train"
        and (record.document_id or record.id) not in validation_group_ids
    ]
    replay_count = min(len(base_train), round(len(feedback_train) * replay_ratio))
    replay = rng.sample(base_train, replay_count) if replay_count else []

    result: list[OCRRecord] = []
    for source_record, split in [
        *((record, "train") for record in feedback_train),
        *((record, "validation") for record in feedback_validation),
    ]:
        image = Path(source_record.image)
        if not image.is_absolute():
            image = (feedback_path.parent / image).resolve()
        result.append(
            OCRRecord(
                id=f"feedback-{source_record.id}",
                image=_portable_relative_path(image, output),
                transcription=source_record.correction,
                split=split,
                domain=source_record.domain,
                language=source_record.language,
                source="reviewed_user_feedback",
                document_id=source_record.document_id or f"feedback-doc-{source_record.id}",
                metadata={
                    "previous_prediction": source_record.prediction,
                    "previous_confidence": source_record.confidence,
                    "hardness": hardness_score(source_record, newest=newest),
                    "created_at": source_record.created_at.isoformat(),
                },
            )
        )
    for record in replay:
        copied = record.model_copy(deep=True)
        copied.id = f"replay-{record.id}"
        copied.source = "base_replay"
        copied.image = _portable_relative_path(record.resolved_image(base_manifest), output)
        result.append(copied)
    for record in base:
        if record.split == "test":
            copied = record.model_copy(deep=True)
            copied.image = _portable_relative_path(record.resolved_image(base_manifest), output)
            result.append(copied)

    output.mkdir(parents=True, exist_ok=True)
    write_manifest(output / "manifest.jsonl", result)
    summary = {
        "raw_feedback": len(loaded_feedback),
        "deduplicated_accepted_feedback": len(feedback),
        "skipped_test_overlap": skipped_test_overlap,
        "feedback_train": len(feedback_train),
        "feedback_validation": len(feedback_validation),
        "replay": len(replay),
        "untouched_test": sum(record.split == "test" for record in base),
        "total": len(result),
    }
    write_json(output / "selection_summary.json", summary)
    return summary


def make_demo_feedback(
    manifest: str | Path, output: str | Path, *, samples: int = 20, seed: int = 43
) -> Path:
    """Create intentionally wrong predictions to demonstrate the feedback flow."""

    rng = random.Random(seed)
    source = [record for record in load_manifest(manifest) if record.split != "test"]
    selected = rng.sample(source, min(samples, len(source)))
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    now = datetime.now(timezone.utc)
    with output.open("w", encoding="utf-8") as stream:
        for index, record in enumerate(selected):
            words = record.transcription.split()
            prediction = " ".join(words[:-1]) if len(words) > 1 else ""
            feedback = FeedbackRecord(
                id=f"demo-feedback-{index:04d}",
                image=_portable_relative_path(record.resolved_image(manifest), output.parent),
                prediction=prediction,
                correction=record.transcription,
                confidence=rng.uniform(0.15, 0.65),
                created_at=now.replace(microsecond=index),
                domain=record.domain,
                language=record.language,
                document_id=f"feedback-{record.document_id or record.id}",
                reporter_count=rng.randint(1, 4),
            )
            stream.write(feedback.model_dump_json(exclude_none=True) + "\n")
    return output

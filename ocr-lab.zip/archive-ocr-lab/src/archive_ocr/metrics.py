from __future__ import annotations

from collections import Counter, defaultdict
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from typing import Any

from .markup import normalize_text, strip_markup_best_effort, tags_only


def edit_distance(reference: Sequence[Any], prediction: Sequence[Any]) -> int:
    """Memory-efficient Levenshtein distance."""

    if len(reference) < len(prediction):
        reference, prediction = prediction, reference
    previous = list(range(len(prediction) + 1))
    for i, ref_item in enumerate(reference, start=1):
        current = [i]
        for j, pred_item in enumerate(prediction, start=1):
            current.append(
                min(
                    current[-1] + 1,
                    previous[j] + 1,
                    previous[j - 1] + (ref_item != pred_item),
                )
            )
        previous = current
    return previous[-1]


def character_error_rate(reference: str, prediction: str) -> float:
    reference = normalize_text(reference)
    prediction = normalize_text(prediction)
    return edit_distance(reference, prediction) / max(1, len(reference))


def word_error_rate(reference: str, prediction: str) -> float:
    reference_words = normalize_text(reference).split()
    prediction_words = normalize_text(prediction).split()
    return edit_distance(reference_words, prediction_words) / max(1, len(reference_words))


def tag_f1(reference: str, prediction: str) -> float:
    """Micro F1 over the markup-token multiset."""

    reference_tags = Counter(tags_only(reference))
    prediction_tags = Counter(tags_only(prediction))
    true_positive = sum((reference_tags & prediction_tags).values())
    predicted = sum(prediction_tags.values())
    actual = sum(reference_tags.values())
    if predicted == 0 and actual == 0:
        return 1.0
    precision = true_positive / max(1, predicted)
    recall = true_positive / max(1, actual)
    return 2 * precision * recall / max(1e-12, precision + recall)


@dataclass
class ErrorAccumulator:
    char_errors: int = 0
    char_total: int = 0
    word_errors: int = 0
    word_total: int = 0
    exact: int = 0
    tag_f1_sum: float = 0.0
    count: int = 0

    def add(self, reference: str, prediction: str) -> None:
        ref_plain = strip_markup_best_effort(reference)
        pred_plain = strip_markup_best_effort(prediction)
        self.char_errors += edit_distance(ref_plain, pred_plain)
        self.char_total += max(1, len(normalize_text(ref_plain)))
        ref_words = normalize_text(ref_plain).split()
        pred_words = normalize_text(pred_plain).split()
        self.word_errors += edit_distance(ref_words, pred_words)
        self.word_total += max(1, len(ref_words))
        self.exact += normalize_text(reference) == normalize_text(prediction)
        self.tag_f1_sum += tag_f1(reference, prediction)
        self.count += 1

    def result(self) -> dict[str, float | int]:
        return {
            "samples": self.count,
            "cer": self.char_errors / max(1, self.char_total),
            "wer": self.word_errors / max(1, self.word_total),
            "exact_match": self.exact / max(1, self.count),
            "tag_f1": self.tag_f1_sum / max(1, self.count),
        }


def evaluate_pairs(references: Iterable[str], predictions: Iterable[str]) -> dict[str, float | int]:
    accumulator = ErrorAccumulator()
    for reference, prediction in zip(references, predictions, strict=True):
        accumulator.add(reference, prediction)
    return accumulator.result()


def sliced_metrics(
    rows: Iterable[Any],
    *,
    reference: Callable[[Any], str],
    prediction: Callable[[Any], str],
    slice_value: Callable[[Any], str],
) -> dict[str, dict[str, float | int]]:
    accumulators: dict[str, ErrorAccumulator] = defaultdict(ErrorAccumulator)
    for row in rows:
        accumulators[slice_value(row)].add(reference(row), prediction(row))
    return {name: accumulator.result() for name, accumulator in sorted(accumulators.items())}

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from .data import OCRCollator, OCRDataset, check_group_leakage, load_manifest
from .markup import strip_markup
from .metrics import evaluate_pairs
from .models import load_trocr, trainable_parameter_summary
from .utils import load_yaml, set_seed, write_json


def run_training(config_path: str | Path) -> dict[str, Any]:
    """Fine-tune a transformer OCR model from a YAML experiment configuration."""

    from transformers import Seq2SeqTrainer, Seq2SeqTrainingArguments

    config = load_yaml(config_path)
    seed = int(config.get("seed", 42))
    set_seed(seed)
    manifest = Path(config["manifest"])
    records = load_manifest(manifest, verify_images=True)
    leakage = check_group_leakage(records)
    if leakage:
        preview = list(leakage.items())[:5]
        raise ValueError(f"document leakage across splits: {preview}")

    train_split = config.get("train_split", "train")
    eval_split = config.get("eval_split", "validation")
    train_records = [record for record in records if record.split == train_split]
    eval_records = [record for record in records if record.split == eval_split]
    if not train_records or not eval_records:
        raise ValueError("both train and evaluation splits must be non-empty")

    processor, model = load_trocr(
        config["model_id"],
        freeze_encoder=bool(config.get("freeze_encoder", False)),
        lora=config.get("lora"),
    )
    max_length = int(config.get("max_target_length", 128))
    model.generation_config.max_length = max_length
    model.generation_config.num_beams = int(
        config.get("training", {}).get("generation_num_beams", 4)
    )
    train_dataset = OCRDataset(train_records, manifest, processor, max_length)
    eval_dataset = OCRDataset(eval_records, manifest, processor, max_length)
    collator = OCRCollator(processor.tokenizer.pad_token_id)
    training = config.get("training", {})
    output_dir = Path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)

    fp16_requested = bool(training.get("fp16", True))
    try:
        import torch

        use_fp16 = fp16_requested and torch.cuda.is_available()
    except ImportError:
        use_fp16 = False

    report_to = training.get("report_to", "none")
    arguments = Seq2SeqTrainingArguments(
        output_dir=str(output_dir / "checkpoints"),
        num_train_epochs=float(training.get("epochs", 5)),
        learning_rate=float(training.get("learning_rate", 1e-4)),
        weight_decay=float(training.get("weight_decay", 0.01)),
        per_device_train_batch_size=int(training.get("train_batch_size", 8)),
        per_device_eval_batch_size=int(training.get("eval_batch_size", 8)),
        gradient_accumulation_steps=int(training.get("gradient_accumulation_steps", 1)),
        warmup_ratio=float(training.get("warmup_ratio", 0.05)),
        eval_strategy="epoch",
        save_strategy="epoch",
        logging_steps=int(training.get("logging_steps", 10)),
        predict_with_generate=True,
        generation_max_length=max_length,
        generation_num_beams=int(training.get("generation_num_beams", 4)),
        load_best_model_at_end=True,
        metric_for_best_model="cer",
        greater_is_better=False,
        save_total_limit=2,
        fp16=use_fp16,
        dataloader_num_workers=int(training.get("dataloader_num_workers", 2)),
        remove_unused_columns=False,
        report_to=[] if report_to in (None, "none") else [str(report_to)],
        seed=seed,
    )

    def compute_metrics(evaluation_prediction: Any) -> dict[str, float]:
        predictions = evaluation_prediction.predictions
        if isinstance(predictions, tuple):
            predictions = predictions[0]
        labels = np.asarray(evaluation_prediction.label_ids).copy()
        labels[labels == -100] = processor.tokenizer.pad_token_id
        prediction_texts = processor.batch_decode(predictions, skip_special_tokens=False)
        reference_texts = processor.batch_decode(labels, skip_special_tokens=False)
        # Remove tokenizer control tokens while retaining our editorial tags.
        controls = set(processor.tokenizer.all_special_tokens) - set(
            processor.tokenizer.additional_special_tokens
        )
        for control in controls:
            prediction_texts = [text.replace(control, "") for text in prediction_texts]
            reference_texts = [text.replace(control, "") for text in reference_texts]
        metrics = evaluate_pairs(reference_texts, prediction_texts)
        return {key: float(value) for key, value in metrics.items() if key != "samples"}

    trainer = Seq2SeqTrainer(
        model=model,
        args=arguments,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=collator,
        compute_metrics=compute_metrics,
    )
    parameter_summary = trainable_parameter_summary(model)
    train_result = trainer.train()
    best_dir = output_dir / "best"
    # A nested PEFT decoder is convenient while training but cannot be recreated
    # by VisionEncoderDecoderModel.from_pretrained alone. Merge its low-rank delta
    # before writing the portable final checkpoint.
    if hasattr(model.decoder, "merge_and_unload"):
        model.decoder = model.decoder.merge_and_unload()
    trainer.save_model(best_dir)
    processor.save_pretrained(best_dir)
    summary = {
        "config": config,
        "train_samples": len(train_records),
        "eval_samples": len(eval_records),
        "parameters": parameter_summary,
        "train_metrics": train_result.metrics,
        "best_checkpoint": trainer.state.best_model_checkpoint,
        "best_metric": trainer.state.best_metric,
    }
    write_json(output_dir / "run_summary.json", summary)
    return summary

from __future__ import annotations

import json
from collections import Counter
from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import Any

from PIL import Image

from .markup import validate_markup
from .schema import OCRRecord


def load_manifest(path: str | Path, *, verify_images: bool = False) -> list[OCRRecord]:
    manifest_path = Path(path)
    records: list[OCRRecord] = []
    seen: set[str] = set()
    with manifest_path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, start=1):
            if not line.strip():
                continue
            try:
                record = OCRRecord.model_validate_json(line)
                validate_markup(record.transcription)
            except Exception as error:
                raise ValueError(f"invalid manifest row {line_number}: {error}") from error
            if record.id in seen:
                raise ValueError(f"duplicate record id at row {line_number}: {record.id}")
            seen.add(record.id)
            if verify_images:
                image_path = record.resolved_image(manifest_path)
                if not image_path.is_file():
                    raise FileNotFoundError(f"missing image for {record.id}: {image_path}")
                with Image.open(image_path) as image:
                    image.verify()
            records.append(record)
    if not records:
        raise ValueError(f"empty manifest: {manifest_path}")
    return records


def write_manifest(path: str | Path, records: Iterable[OCRRecord]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        for record in records:
            stream.write(record.model_dump_json(exclude_none=True) + "\n")


def manifest_summary(records: Sequence[OCRRecord]) -> dict[str, Any]:
    return {
        "records": len(records),
        "splits": dict(Counter(record.split for record in records)),
        "domains": dict(Counter(record.domain for record in records)),
        "languages": dict(Counter(record.language for record in records)),
        "degradations": dict(
            Counter(degradation for record in records for degradation in record.degradation)
        ),
        "documents": len({record.document_id or record.id for record in records}),
    }


def check_group_leakage(records: Sequence[OCRRecord]) -> dict[str, list[str]]:
    groups: dict[str, set[str]] = {}
    for record in records:
        group = record.document_id or record.id
        groups.setdefault(group, set()).add(record.split)
    return {group: sorted(splits) for group, splits in groups.items() if len(splits) > 1}


class OCRDataset:
    """Lazy PyTorch-compatible line dataset without importing torch at module import time."""

    def __init__(
        self,
        records: Sequence[OCRRecord],
        manifest_path: str | Path,
        processor: Any,
        max_target_length: int,
    ) -> None:
        self.records = list(records)
        self.manifest_path = Path(manifest_path)
        self.processor = processor
        self.max_target_length = max_target_length

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        with Image.open(record.resolved_image(self.manifest_path)) as image:
            pixel_values = self.processor(images=image.convert("RGB"), return_tensors="pt").pixel_values[0]
        labels = self.processor.tokenizer(
            record.transcription,
            padding=False,
            truncation=True,
            max_length=self.max_target_length,
        ).input_ids
        return {"pixel_values": pixel_values, "labels": labels, "id": record.id}


class OCRCollator:
    def __init__(self, pad_token_id: int) -> None:
        self.pad_token_id = pad_token_id

    def __call__(self, features: list[dict[str, Any]]) -> dict[str, Any]:
        import torch

        pixel_values = torch.stack([feature["pixel_values"] for feature in features])
        max_length = max(len(feature["labels"]) for feature in features)
        labels = []
        for feature in features:
            padded = feature["labels"] + [self.pad_token_id] * (max_length - len(feature["labels"]))
            labels.append([token if token != self.pad_token_id else -100 for token in padded])
        return {"pixel_values": pixel_values, "labels": torch.tensor(labels, dtype=torch.long)}


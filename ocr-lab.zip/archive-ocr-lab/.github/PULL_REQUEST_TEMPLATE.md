## Hypothesis

<!-- State one falsifiable hypothesis. -->

## Change

<!-- Describe the single main changed factor and the baseline. -->

## Data and split

<!-- Dataset version, license, document/writer grouping, leakage checks. -->

## Results

| Metric | Baseline | Candidate | Delta |
|---|---:|---:|---:|
| Overall CER |  |  |  |
| Worst-slice CER |  |  |  |
| Tag F1 |  |  |  |
| Latency p95 |  |  |  |

## Reproduction

<!-- Exact config, seed, hardware, and command. -->

## Checklist

- [ ] CPU tests and `compileall` pass.
- [ ] Only validation was used for model selection.
- [ ] Test data did not enter training, replay, or hard-case selection.
- [ ] New behavior has a focused test.
- [ ] No checkpoints, private data, credentials, or absolute local paths were committed.
- [ ] Limitations and regression slices are documented.


# Первичные и официальные источники

- Yandex Cloud Vision OCR API: https://yandex.cloud/en/docs/vision/ocr/api-ref/TextRecognition/recognize
- TrOCR paper: https://arxiv.org/abs/2109.10282
- TrOCR documentation: https://huggingface.co/docs/transformers/model_doc/trocr
- Donut paper: https://arxiv.org/abs/2111.15664
- Qwen2.5-VL technical report: https://arxiv.org/abs/2502.13923
- Qwen2.5-VL Transformers documentation: https://huggingface.co/docs/transformers/model_doc/qwen2_5_vl
- LoRA paper: https://arxiv.org/abs/2106.09685
- PEFT LoRA documentation: https://huggingface.co/docs/peft/package_reference/lora
- Optimum ORT vision encoder-decoder support:
  https://huggingface.co/docs/optimum-onnx/onnxruntime/package_reference/modeling_ort
- Bentham HTR competition page: https://tc11.cvc.uab.es/datasets/HTR%20Competition%202014_1/task_1_1
- ImageCLEF Bentham subset: https://zenodo.org/records/52994

Источники объясняют выбор публичных baseline-компонентов. Они не подтверждают, что эти же
модели или библиотеки используются внутри Яндекса.


# План экспериментов

Не менять одновременно модель, данные и loss. Каждый эксперимент должен отвечать на одну
проверяемую гипотезу и использовать фиксированный document-disjoint test.

| ID | Гипотеза | Изменение | Primary metric | Guardrails |
|---|---|---|---|---|
| E0 | Pipeline корректен | TrOCR без domain FT | CER | latency, tag F1 |
| E1 | Архивные augmentations улучшают сложные сканы | + blur/fold/fade/stain | challenge CER | clean CER ≤ +1 п.п. |
| E2 | Явные токены учат правки | + del/add/unclear | tag F1 | plain CER |
| E3 | Кириллическая адаптация важнее размера | multilingual/tokenizer variant | ru CER | en CER, params |
| E4 | LoRA достаточно для нового домена | LoRA vs full FT | CER при равном budget | trainable params |
| E5 | Feedback исправляет реальные hard cases | selected feedback + replay | future-window CER | base-test CER |
| E6 | VLM лучше понимает сложный layout | Qwen-VL prompt baseline | tag F1, page CER | cost, latency |
| E7 | Student сохраняет teacher quality | distillation | CER delta | mobile p95/RAM |
| E8 | INT8 приемлем | ONNX FP32 vs INT8 | parity/CER delta | device latency |

## Обязательные срезы

- язык и письменность;
- архив/источник;
- писец и документ;
- printed/handwritten/mixed;
- зачёркивание, вставка, unclear;
- blur, fold, stain, fade, rotation, compression;
- длина строки и число специальных операций.

## Статистическая дисциплина

- bootstrap confidence interval по документам, а не по отдельным строкам;
- один заранее выбранный primary metric;
- paired comparison на одних и тех же документах;
- test открывается после выбора гипотезы/checkpoint;
- latency измеряется с warm-up, фиксированным batch и p50/p95.

## Карточка результата

Для каждого запуска сохранить:

```yaml
git_commit: ...
config: configs/train_trocr.yaml
data_version: ...
seed: 42
hardware: ...
primary_metric: cer
overall: ...
worst_slices: ...
train_time: ...
inference_p50_p95: ...
decision: keep | reject | investigate
```


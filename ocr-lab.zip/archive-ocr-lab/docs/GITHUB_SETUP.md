# Публикация на GitHub

## 1. Создайте пустой репозиторий

На GitHub выберите **New repository**:

- Repository name: `archive-ocr-lab`
- Description: `Transformer OCR, VLM and continual learning for archival manuscripts`
- Visibility: Public
- Не добавляйте README, `.gitignore` или license — они уже находятся в проекте.

Рекомендуемые topics:

```text
ocr htr computer-vision transformers vlm pytorch digital-humanities archival-documents
```

## 2. Первый push

После распаковки GitHub-ready архива:

```bash
cd archive-ocr-lab
git init
git add .
git commit -m "Initial public release"
git branch -M main
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/archive-ocr-lab.git
git push -u origin main
```

Для SSH замените remote:

```bash
git remote set-url origin git@github.com:<YOUR_GITHUB_USERNAME>/archive-ocr-lab.git
```

## 3. После публикации

В настройках репозитория:

1. включите Issues;
2. запретите force push в `main`;
3. потребуйте прохождение workflow `ci` для pull request;
4. добавьте короткое описание и topics;
5. проверьте, что изображение в README отображается;
6. создайте release `v0.1.0`, когда появятся первые реальные benchmark-результаты.

## 4. Что не следует заявлять в README

- что это внутренний стек или модель Яндекса;
- качество на Толстом без реального held-out корпуса;
- mobile readiness без benchmark на телефоне;
- production readiness исследовательского prototype;
- превосходство VLM/TrOCR без одинакового test split и compute budget.

## 5. Что улучшит репозиторий перед интервью

Запустите один небольшой реальный эксперимент и добавьте в отдельный pull request:

- experiment config;
- data card без самих закрытых данных;
- `metrics.json`;
- несколько обезличенных predictions/errors;
- короткий вывод: гипотеза подтверждена или отклонена.


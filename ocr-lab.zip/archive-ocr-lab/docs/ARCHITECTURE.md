# Архитектурные решения

## 1. Почему pipeline, а не сразу full-page VLM

Line-level recognizer даёт контролируемую задачу и понятную диагностику: можно независимо
измерить layout recall/precision и ошибку распознавания. Full-page VLM полезна как baseline,
но её ошибка смешивает чтение, порядок строк, структуру и следование prompt.

Для простых страниц используется projection profile. Для сложных рукописей контракт остаётся
тем же, а реализацию следует заменить на learned detector/segmenter.

## 2. Почему TrOCR

Он прямо соответствует стыку CV и NLP: visual Transformer кодирует изображение, text
Transformer генерирует последовательность и вносит language prior. Это понятный открытый
baseline для проверки data/metrics pipeline. Выбор baseline не означает, что он лучший для
русской архивной рукописи.

## 3. Как представлена авторская правка

Target — одна последовательность с шестью специальными токенами. Это проще отдельного
графового декодера и позволяет начать с обычного cross-entropy. Цена простоты: невозможно
выразить вложенные/пересекающиеся операции и точную геометрию связи вставки с местом.

Следующий формат — два связанных выхода:

- дипломатическая транскрипция в TEI-подобном виде;
- геометрический JSON/PAGE XML с polygon, reading order и связями операций.

## 4. Data split

Единица split — `document_id`, а при достаточном объёме — `writer_id`. Случайный line split
завышает качество: модель видит тот же почерк, бумагу, сканер и соседний контекст.

Для feedback используется temporal split, но тоже целыми документами. Последние документы
имитируют будущий трафик. Исходный test не участвует ни в hard mining, ни в replay.

## 5. Continual learning

Reviewed corrections ранжируются по ошибке, uncertainty, recency и повторяемости. В train
добавляется base replay, чтобы снизить catastrophic forgetting. Это осознанно простой baseline.

Production policy должна иметь минимум три уровня:

1. ingestion: moderation, PII, license, abuse/poisoning checks;
2. selection: dedup, domain quotas, diversity, hard-case score;
3. release: frozen regression suites, canary, slice gates, rollback.

## 6. Mobile

LoRA уменьшает стоимость fine-tuning, но сама по себе не ускоряет merged inference. ONNX/INT8
проверяет deployability, однако autoregressive decoder может оставаться слишком дорогим.
Решение выбирается только после benchmark на целевом железе. Возможные направления:

- distillation в меньший encoder-decoder;
- non-autoregressive/CTC student для простых доменов;
- conditional routing: on-device для простого, server VLM для сложного;
- early exit и ограничение generation length;
- quantization-aware training, pruning и operator-level profiling.

## 7. Наблюдаемость

API должен логировать модель/версию, latency, размер входа, число строк, confidence и доменную
категорию без сохранения пользовательского изображения по умолчанию. Offline мониторинг:
drift по языкам/доменам, доля fallback, bug-report rate, slice CER на reviewed sample.

